<?php  if(!defined('BASEPATH')) exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html>

<head>
    <!-- tempat Meta  -->
    <?php $this->load->view($folder_themes.'/partials/meta.php');?>
    <!-- tutup meta  -->
    <!-- ----------------------------- -->
    <!--  Tempat CSS -->
    <?php $this->load->view($folder_themes.'/partials/css.php');?>
    <!--  Tutup CSS -->
 
</head>

<body>
  <!-- top Pengunjung  -->
  <?php $this->load->view($folder_themes.'/partials/pengunjung.php');?>
  <!-- Tutup top Pengunjung  -->
  <!-- ----------------------------- -->
  <!-- Tempat Menu  -->
  <?php $this->load->view($folder_themes.'/partials/menu.php');?>
  <!-- Tutup  Menu  -->
 
  <!-- tepat Slide Header  -->
  <?php $this->load->view($folder_themes.'/partials/slider.php');?>
  <!-- Tutup Slider Header   -->
  <!-- ----------------------------- -->
  <!-- content  -->
  <?php $this->load->view($folder_themes.'/partials/content.php');?>
  </div>
  <?php $this->load->view($folder_themes.'/partials/sinergi.php');?>
  <?php $this->load->view($folder_themes.'/partials/aparatur.php');?>
  <div class="py-5 text-center">
    <div class="container pb-5">
    <h1 contenteditable="true">Pengembang </h1>
          <p class="mb-3 mx-auto w-75">Dengan Segenap Hati  Kam Dari Team Getcoding Berterima Kasih Kepada OpenSID Dan Lumbung Komunitas Sebagai Pelopor Dalam Pengembangan Aplikasi Ini.</p>
          
    </div>
    <div class="container pb-5">
      <div class="row ">
        
        <div class="col-md-4 col-4 p-2 mx-auto"> <img class="img-fluid d-block mx-auto" src="https://i.ibb.co/3sBDsQf/opensid.png" width="174" height="84"> </div>
        <div class="col-md-4 col-4 p-2"><img class="img-fluid d-block mx-auto" src="https://i.ibb.co/HVFnzq0/get.png" width="174" height="84"></div>
        <div class="col-md-4 col-4 p-2"><img class="img-fluid d-block mx-auto" src="https://i.ibb.co/drhFJn2/pingendo.png" width="174" height="84"></div>
      </div>
    </div>
  </div>
  <!-- tutup content  -->
 
<!--  Tempat  Footer  -->
<?php $this->load->view($folder_themes.'/partials/footer.php');?>
 
  <!-- Script  -->
  <?php $this->load->view($folder_themes.'/partials/script.php');?>
  <!-- ----------------------------- -->
</body>

</html>