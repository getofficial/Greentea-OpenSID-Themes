<!DOCTYPE html>
<html>

<head>
<head>
    <!-- tempat Meta  -->
    <?php $this->load->view($folder_themes.'/partials/meta.php');?>
    <!-- tutup meta  -->
    <!-- ----------------------------- -->
    <!--  Tempat CSS -->
    <?php $this->load->view($folder_themes.'/partials/css.php');?>
    <!--  Tutup CSS -->
 
</head>
</head>

<body>
    <!-- top Pengunjung  -->

  <!-- Tutup top Pengunjung  -->
  <!-- ----------------------------- -->
  <!-- Tempat Menu  -->
  <?php $this->load->view($folder_themes.'/partials/menu.php');?>
  <!-- Tutup  Menu  -->
  <div class="modal fade bg-primary bg-get" id="myModal">
    <div class="modal-dialog modal-lg" role="dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">LOGIN MANDIRI&nbsp;</h5> <button type="button" class="close" data-dismiss="modal"> <span>×</span> </button>
        </div>
        <div class="bg-white p-5">
          <form>
            <div class="form-group"> <input type="number" class="form-control" placeholder="Masukan NIK anda" id="form9" required="required"> </div>
            <div class="form-group mb-3"> <input type="password" class="form-control" placeholder="Masukan Kode PIN Anda" id="form10"> </div> <button type="submit" class="btn btn-primary py-3">Login Mandiri</button>
          </form>
        </div>
      </div>
    </div>
  </div>
  <div class="py-5 bg-get">
    <div class="container">
      <div class="row">
        <div class="px-5 col-md-8 text-center mx-auto">
          <h3 class="text-primary display-4 py-5"><b>#Artikel&nbsp;</b><br></h3>
        </div>
      </div>
    </div>
  </div>
<!-- conten start -->
<?php $this->load->view($folder_themes.'/partials/artikel.php');?>
        <!-- conten end -->     
  <!-- /.container -->
  <!-- Script  -->
  <?php $this->load->view($folder_themes.'/partials/footer.php');?>
  <?php $this->load->view($folder_themes.'/partials/script.php');?>
  <!-- ----------------------------- -->
</body>

</html>