<?php  if(!defined('BASEPATH')) exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html>

<head>
<head>
    <!-- tempat Meta  -->
    <?php $this->load->view($folder_themes.'/partials/meta.php');?>
    <!-- tutup meta  -->
    <!-- ----------------------------- -->
    <!--  Tempat CSS -->
    <?php $this->load->view($folder_themes.'/partials/css.php');?>
    <!--  Tutup CSS -->
 
</head>
</head>

<body>
    <!-- top Pengunjung  -->
 
  <!-- Tutup top Pengunjung  -->
  <!-- ----------------------------- -->
  <!-- Tempat Menu  -->
  <?php $this->load->view($folder_themes.'/partials/menu.php');?>
  <!-- Tutup  Menu  -->
  <div class="modal fade bg-primary bg-get" id="myModal">
    <div class="modal-dialog modal-lg" role="dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">LOGIN MANDIRI&nbsp;</h5> <button type="button" class="close" data-dismiss="modal"> <span>×</span> </button>
        </div>
        <div class="bg-white p-5">
          <form>
            <div class="form-group"> <input type="number" class="form-control" placeholder="Masukan NIK anda" id="form9" required="required"> </div>
            <div class="form-group mb-3"> <input type="password" class="form-control" placeholder="Masukan Kode PIN Anda" id="form10"> </div> <button type="submit" class="btn btn-primary py-3">Login Mandiri</button>
          </form>
        </div>
      </div>
    </div>
  </div>
  <div class="py-5 bg-get">
    <div class="container">
      <div class="row">
        <div class="px-5 col-md-8 text-center mx-auto">
          <h3 class="text-primary display-4 py-5"><b>#Statistik&nbsp;</b><br></h3>
        </div>
      </div>
    </div>
  </div>
  <div class="container-fluid">
    <div class="row">
      <nav class="col-md-2 d-none d-md-block bg-light sidebar bg-get">
        <div class="sidebar-sticky" style="">
          <ul class="nav flex-column pt-3">
          <div class="col-md-12">
          <ul class="list-group" >



            <li class=" btn btn-primary text-light bg-get"><a class="nav-link" href="<?php echo base_url()?>/index.php/first/wilayah"> Wilayah </a> </li>
            <li class=" btn btn-primary text-light bg-get"><a class="nav-link" href="<?php echo base_url()?>/index.php/first/statistik/0"> Pendidikan KK </a> </li>
            <li class=" btn btn-primary text-light bg-get"><a class="nav-link" href="<?php echo base_url()?>/index.php/first/statistik/14"> Pendidikan </a> </li>
            <li class=" btn btn-primary text-light bg-get"><a class="nav-link" href="<?php echo base_url()?>/index.php/first/statistik/1"> Pekerjaan </a> </li>
            <li class=" btn btn-primary text-light bg-get"><a class="nav-link" href="<?php echo base_url()?>/index.php/first/statistik/3"> Agama </a> </li>
            <li class=" btn btn-primary text-light bg-get"><a class="nav-link" href="<?php echo base_url()?>/index.php/first/statistik/4"> Kelamin </a> </li>
            <li class=" btn btn-primary text-light bg-get"><a class="nav-link" href="<?php echo base_url()?>/index.php/first/statistik/13"> Warga </a> </li>
<br>
        </ul>
        </div>               
          </ul>
        </div>
      </nav>
      <main role="main" class="col-md-9 ml-sm-auto col-lg-10 pt-3 px-4">
        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
          
          
        </div>
       
        <?php
                        if($tipe == 2){
                            if($tipex==1){
                                $this->load->view($folder_themes.'/partials/statistik_sos.php');
                            }
                        }elseif($tipe == 3){
                            $this->load->view($folder_themes.'/partials/wilayah.php');
                        }elseif($tipe == 4){
                            $this->load->view($folder_themes.'/statistik/dpt.php');
                        }else{
                            $this->load->view($folder_themes.'/partials/statistik.php');
                        }
                    ?>
                    </div>
    
                    </div>
        
                    	


  <?php $this->load->view($folder_themes.'/partials/script.php');?>
   <!-- Graphs -->
  
  
        
    </body>
  
</html>