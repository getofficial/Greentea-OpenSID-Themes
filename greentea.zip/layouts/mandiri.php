
<?php  if(!defined('BASEPATH')) exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html>

<head>
    <!-- tempat Meta  -->
    <?php $this->load->view($folder_themes.'/partials/meta.php');?>
    <!-- tutup meta  -->
    <!-- ----------------------------- -->
    <!--  Tempat CSS -->
    <?php $this->load->view($folder_themes.'/partials/css.php');?>
    <!--  Tutup CSS -->
 
</head>

<body>
  <!-- top Pengunjung  -->
  <?php $this->load->view($folder_themes.'/partials/pengunjung.php');?>
  <!-- Tutup top Pengunjung  -->
  <!-- ----------------------------- -->
  <!-- Tempat Menu  -->
  <?php $this->load->view($folder_themes.'/partials/menu.php');?>
  <!-- Tutup  Menu  -->
   <!-- tepat Slide Header  -->
  
  <!-- Tutup Slider Header   -->
  <!-- ----------------------------- -->
  <!-- content  -->
  <?php 
                        $views_partial_layout = '';
                        switch($m){
                            case 1 :
                                $views_partial_layout = $folder_themes.'/partials/mandiri.php';
                                break;
                            case 2 :
                                $views_partial_layout = $folder_themes.'/partials/layanan.php';
                                break;
                            case 4 :
                                $views_partial_layout = $folder_themes.'/partials/bantuan.php';
                                break;
                            default:
                                $views_partial_layout = $folder_themes.'/partials/lapor.php';
                        }
                        $this->load->view($views_partial_layout);
                    ?>
  </div>
 
<!--  Tempat  Footer  -->

 
  <!-- Script  -->
  <?php $this->load->view($folder_themes.'/partials/script.php');?>
  <!-- ----------------------------- -->
</body>

</html>


