<?php  if(!defined('BASEPATH')) exit('No direct script access allowed'); ?>
<nav class="navbar navbar-expand-lg navbar-light bg-get sticky-top">
    <div class="container-fluid"> <a class="navbar-brand text-primary" href="<?php echo site_url(); ?>first/">
        <i class="fa d-inline fa-lg fa-globe text-light"></i>
        <b class="text-light"> <?php echo $desa['nama_desa'];?></b>
      </a> <button class="navbar-toggler navbar-toggler-right border-0" type="button" data-toggle="collapse" data-target="#navbar5">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbar5">
        <ul class="navbar-nav ml-auto text-light">
        <li class="nav-item" ><a class="nav-link" href="<?php echo site_url(); ?>first/">Beranda</a></li>
         <?php foreach($menu_atas as $data){?>
                          
                            <li class="nav-item dropdown"><a class="nav-link dropdown-toggle" data-toggle="dropdown"  href="<?php echo $data['link']; ?>" role="button" aria-haspopup="true" aria-expanded="false"><?php echo $data['nama']; ?></a>
                                <?php if(count($data['submenu'])>0): ?>
                                <div class="dropdown-menu">
                                    <?php foreach($data['submenu'] as $submenu): ?>
                                    <a class="dropdown-item" href="<?php echo $submenu['link']?>"><?php echo $submenu['nama']?></a>
                                    <?php endforeach; ?>
                                    </div>
                                <?php endif; ?>
                            </li>
                            <?php } ?>
                            <li class="nav-item" ><a class="nav-link" href="<?php echo site_url(); ?>first/gallery">Galeri</a></li>
                            
        </ul> 
        <?php if(!isset($_SESSION['mandiri']) OR $_SESSION['mandiri']<>1){ ?> 
        <div class="btn-group dropleft  pl-3" >
        
            <button class="btn btn-primary dropdown-toggle" data-toggle="dropdown"> Mandiri </button>
            <div class="dropdown-menu">
              <form class="m-3" action="<?php echo site_url('first/auth')?>" method="post">
                <div class="form-group">
                  
                  <input type="number" class="form-control" name="nik" placeholder="NIK">
                </div>
                <div class="form-group">
                  
                  <input type="password" class="form-control" name="pin"  placeholder="PIN">
                </div>
                
                <button type="submit" class="btn btn-success ">Login</button>
              </form>
              
              <div class="dropdown-divider"></div>
              <?php
                                      if(isset($_SESSION['mandiri']) AND $_SESSION['mandiri']==-1){
                                        echo "<script>alert('NIK atau PIN yang anda masukkan salah')</script>";
                                        unset($_SESSION['mandiri']);      
                                      }
                                    ?>
              
              <a class="dropdown-item" href="#">Cara Dapatkan PIN?</a>
            </div>
          </div>
       
        </div>
        <?php }else{ ?>
          <div class="btn-group dropleft  pl-3" >
            <button class="btn btn-primary dropdown-toggle" data-toggle="dropdown"> Akun Saya</button>
            <div class="dropdown-menu">
              <a class="dropdown-item" href="<?php echo site_url();?>first/mandiri/1/1"><i class="fa fa-user"></i> &nbsp;&nbsp; Profil Pengguna</a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="<?php echo site_url();?>first/mandiri/1/2"><i class="fa fa-file"></i> &nbsp;&nbsp; Semua Layanan</a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="<?php echo site_url();?>first/mandiri/1/3"><i class="fa fa-comment"></i> &nbsp;&nbsp; Lapor Pengaduan</a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="<?php echo site_url();?>first/mandiri/1/4"><i class="fa fa-gift"></i> &nbsp;&nbsp; Daftar Bantuan</a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="<?php echo site_url();?>first/logout"><i class="fa fa-user"></i> &nbsp;&nbsp; Keluar</a>
                             
            </div>
          </div>
          <?php } ?>
      </div>
    </div>
  </nav>
  