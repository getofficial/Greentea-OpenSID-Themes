

  

      <!-- Swiper -->
  <div class="py-5 bg-get" style="	background-attachment: fixed;" >
    <div class="container">
      <div class="row">
        
      </div>
      <div class="swiper-container">
        <div class="swiper-wrapper">
        <?php foreach($aparatur_desa as $data) : ?>
        <div class="p-3 col-2 col-sm-2 col-md-3 col-lg-3">
        <?php if(AmbilFoto($data['foto'],"besar") AND is_file(LOKASI_USER_PICT.$data['foto'])) : ?>
          <div class="card box-shadow card-shadow"> <img class="card-img-top" src="<?php echo AmbilFoto($data['foto'],"besar") ?>" alt="" />
          <?php endif; ?>
            <div class="card-body">
              <h5 class="card-title"> <b><?php echo $data['pamong_nama'] ?></b> </h5>
              <p class="card-text"><?php echo $data['jabatan'] ?></p>
            </div>
          </div>
        </div>
        <?php endforeach; ?>
 
        </div>
<br>
        <!-- Add Pagination -->
        <div class="swiper-pagination"></div>
      </div>
      </div>  
      </div>  
    
      <!-- Swiper JS -->
      <script src='<?php echo base_url("$this->theme_folder/themes1/swipper/js/swiper.min.js"); ?>'></script>
    
      <!-- Initialize Swiper -->
      <script>
        var swiper = new Swiper('.swiper-container', {
          slidesPerView: 3,
          slidesPerColumn: 2,
          spaceBetween: 30,
          pagination: {
            el: '.swiper-pagination',
            clickable: true,
          },
        });
      </script>
      