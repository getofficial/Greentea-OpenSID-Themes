<link rel="stylesheet" href="<?php echo base_url()?>assets/css/jquery-ui-1.12.1.css">
<script src="<?php echo base_url()?>assets/js/jquery-ui.min.js"></script>
<script>
  function show_kartu_peserta(elem){
    var id = elem.attr('target');
    var title = elem.attr('title');
    var url = elem.attr('href');
    $('#'+id+'').remove();

    $('body').append('<div id="'+id+'" title="'+title+'" style="display:none;position:relative;overflow:scroll;"></div>');

    $('#'+id+'').dialog({
      resizable: true,
      draggable: true,
      width: 500,
      height: 'auto',
      open: function(event, ui) {
        $('#'+id+'').load(url);
      }
    });
    $('#'+id+'').dialog('open');
  }
</script>


<div class="py-5 text-center" style="">
    <div class="container">
      <div class="row">
        <div class="mx-auto col-lg-5 col-md-7 col-10">
                <h3 style="">DAFTAR REKAM CETAK SURAT</h3>
          
           </div>
      </div>
    </div>
  </div>
  <div class="py-5">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
        <div class="table-responsive " >
        <?php if(!empty($daftar_bantuan)): ?>
            <table class="table table-bordered ">
              <thead class="thead-dark">
                <tr>
                <th style="text-align: center;vertical-align: middle;">Nama</th>
          <th style="text-align: center;vertical-align: middle;">Awal</th>
          <th style="text-align: center;vertical-align: middle;">Akhir</th>
          <th style="text-align: center;vertical-align: middle;">ID KARTU</th>
                </tr>
              </thead>
              <tbody>
              <?php foreach ($daftar_bantuan as $bantuan) : ?>
        <tr>
          <td><?php echo $bantuan['nama']?></td>
          <td><?php echo tgl_indo($bantuan['sdate'])?></td>
          <td><?php echo tgl_indo($bantuan['edate'])?></td>
          <td>
            <?php if($bantuan['no_id_kartu']) : ?>
              <button type="button" target="kartu_peserta" title="Kartu Peserta" href="<?php echo site_url('first/kartu_peserta/'.$bantuan['id'])?>" onclick="show_kartu_peserta($(this));" class="uibutton special waves-effect waves-light btn"><span class="fa fa-print">&nbsp;</span><?php echo $bantuan['no_id_kartu']?></button>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
		</tbody>
            </table>
            <?php else: ?>
    <span>Anda tidak terdaftar dalam program bantuan apapun</span>
  <?php endif; ?>
          </div>
         
        </div>
      </div>
    </div>
  </div>