<div class="py-4 bg-light text-left">
    <div class="container py-5">
		
      <div class="row">
		
      <?php
                if($artikel){
              		foreach($artikel as $data){
	              		if($data['gambar']!='' && is_file(LOKASI_FOTO_ARTIKEL."sedang_".$data['gambar']) ){
	              			$gmbr = AmbilFotoArtikel($data['gambar'],'sedang');
	              		}else{
	              			$gmbr = THEMES_PATH.$this->theme_folder.'/'.$this->theme.'/'."assets/img/blog/blog-12.jpg";
	              		}	
	              		$expl =explode(" ",$data['tgl_upload']);
	              		$tglexpl = explode("-", $expl[0]);
	              		$bulan = array('01' => 'JAN','02' => 'PEB','03' => 'MAR','04' => 'APR','05' => 'MEI','06' => 'JUN','07' => 'JUL','08' => 'AGU','09' => 'SEP','10' => 'OKT','11' => 'NOP','12' => 'DES');
              	?>	
        <div class="p-3 col-md-4 col-lg-4">
          <div class="card box-shadow card-shadow" style="">

					<?php if ($data['gambar']!=''): ?>
										<?php if (is_file(LOKASI_FOTO_ARTIKEL."kecil_".$data['gambar'])): ?>
											<img  class="card-img-top" src="<?= AmbilFotoArtikel($data['gambar'],'kecil') ?>" alt="<?= $data["judul"] ?>" style="	box-shadow: 0px 0px 4px  black;"/>
										<?php else: ?>
											<img src="<?= base_url('assets/images/404-image-not-found.jpg') ?>" alt="<?= $data["judul"] ?>" />
										<?php endif;?>
									<?php endif; ?>
            
            <div class="card-body">
              <p class="card-text"><p><?php echo potong_teks(strip_tags($data['isi']), 150); ?> ...</p></p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <a href="<?php echo site_url('first/artikel/').$data['id']; ?>" type="button" class="btn btn-sm btn-outline-secondary">Baca</a>
                  <a type="button" class="btn btn-sm btn-outline-primary" href="<?php echo site_url('first/kategori/').$data['id_kategori']; ?>"><?php echo $data['kategori']; ?></a>
                </div> <small class="text-muted"> <?php echo $tglexpl[2]; ?>-<?php echo $bulan[$tglexpl[1]]; ?></small>
              </div>
            </div>
          </div>
        </div>
        <?php 
            		} 
            	}else{
            		echo "<center>Tidak ada artikel</center>";
            	}
            	?>
    </div>
  </div>

	<div class="py-5">
    <div class="container">
      <div class="row">
        <div class="mx-auto">
          <ul class="pagination" >
					<?php
              	if($paging->start_link){
										echo "<li class=\"page-item\"><a href=\"".site_url("first/".$paging_page."/$paging->start_link" . $paging->suffix)."\" title=\"Halaman Pertama\" class=\"page-link\">Halaman Pertama</a></li>";
        		
        				}
        				if($paging->prev){
        					echo "<li class=\"page-item\"><a href=\"".site_url("first/".$paging_page."/$paging->prev" . $paging->suffix)."\" title=\"Halaman Sebelumnya\" class=\"page-link\">Halaman Sebelumnya</a></li>";
								}
								if($paging->next){
        					echo "<li class=\"page-item\"><a href=\"".site_url("first/".$paging_page."/$paging->next" . $paging->suffix)."\" title=\"Halaman Selanjutnya\" class=\"page-link\">Halaman Selanjutnya</a></li>";
								}
								if($paging->end_link){
        					echo "<li class=\"page-item\"><a href=\"".site_url("first/".$paging_page."/$paging->end_link" . $paging->suffix)."\" title=\"Halaman Terakhir\" class=\"page-link\">Halaman Terakhir</a></li>";
        				}
								?>
            
          </ul>
        </div>
      </div>
    </div>
  </div>