
<div class="py-5 text-center" style="">
    <div class="container">
      <div class="row">
        <div class="mx-auto col-lg-5 col-md-7 col-10">
                <h3 style="">DAFTAR REKAM CETAK SURAT</h3>
          
           </div>
      </div>
    </div>
  </div>
  <div class="py-5">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
        <div class="table-responsive">
            <table class="table table-bordered ">
              <thead class="thead-dark">
                <tr>
                <th style="text-align: center;vertical-align: middle;">No</th>
				<th style="text-align: center;vertical-align: middle;">Nomor Surat</th>
				<th style="text-align: center;vertical-align: middle;">Jenis Surat</th>
				<th style="text-align: center;vertical-align: middle;">Nama Staf</th>
				<th style="text-align: center;vertical-align: middle;">Tanggal</th>
                </tr>
              </thead>
              <tbody>
              <?php foreach($surat_keluar as $data): ?>
				<tr>
					<td align="center" width="2"><?php echo $data['no']?></td>
					<td><?php echo $data['no_surat']?></td>
					<td><?php echo $data['format']?></td>
					<td><?php echo $data['pamong']?></td>
					<td><?php echo tgl_indo2($data['tanggal'])?></td>
				</tr>
			<?php endforeach; ?>
		</tbody>
            </table>
          </div>
         
        </div>
      </div>
    </div>
  </div>