<?php  if(!defined('BASEPATH')) exit('No direct script access allowed'); ?>
<div class="py-4 text-center">
    <div class="container">
      <div class="row">
      <?php foreach($gallery AS $data): ?>
        <div class="col-lg-4 p-3">
          <div class="card">
            <div class="card-body p-4 bg-get card-shadow">
            <?php if(is_file(LOKASI_GALERI . "sedang_" . $data['gambar'])): ?>
             <img class="img-fluid d-block mb-3 mx-auto img-thumbnail" src="<?php echo AmbilGaleri($data['gambar'], 'sedang'); ?>">
             <h3><a href="<?php echo site_url().'first/sub_gallery/'.$data['id']; ?>"><?php echo $data["nama"]; ?></a></h3>
             <h1><a type="btn" class="btn btn-primary" href="<?php echo AmbilGaleri($data['gambar'], 'sedang'); ?>"  title=""><i class="fa fa-eye"></i></a></h1>
            </div>
          </div>
          <?php endif; ?>
        </div>
        <?php endforeach; ?>
       </div>
    </div>
  </div>
  <div class="py-5">
    <div class="container">
      <div class="row">
        <div class="mx-auto">
          <ul class="pagination" >
					<?php
              			if($paging->start_link){
        					echo "<li><a href=\"".site_url("first/sub_gallery/".$parrent['id']."/".$paging->start_link)."\" title=\"Halaman Pertama\" class=\"page-link\"><i class=\"fa fa-angle-left\"></i>&nbsp;</a></li>";
        				}
        				if($paging->prev){
        					echo "<li><a href=\"".site_url("first/sub_gallery/".$parrent['id']."/".$paging->prev)."\" title=\"Halaman Sebelumnya\" class=\"page-link\"><i class=\"fa fa-angle-left\"></i>&nbsp;</a></li>";
        				}
        				for($i=$paging->start_link;$i<=$paging->end_link;$i++){
        					if ($p != $i) {
        						echo "<li><a href=\"".site_url("first/sub_gallery/".$parrent['id']."/".$i)."\" title=\"Halaman ".$i."\"  class=\"page-link\">".$i."</a></li>";
        					}else{
        						echo "<li><span class=\"current page-link\">".$i."</span></li>";
        					}
        										
        				}
        				if($paging->next){
        					echo "<li><a href=\"".site_url("first/sub_gallery/".$parrent['id']."/".$paging->next)."\" title=\"Halaman Selanjutnya\" class=\"page-link\"><i class=\"fa fa-angle-right\"></i>&nbsp;</a></li>";
        				}
        				if($paging->end_link){
        					echo "<li><a href=\"".site_url("first/sub_gallery/".$parrent['id']."/".$paging->end_link)."\" title=\"Halaman Terakhir\" class=\"page-link\"><i class=\"fa fa-angle-right\"></i>&nbsp;</a></li>";
        				}
        			?>
            
          </ul>
        </div>
      </div>
    </div>
  </div>