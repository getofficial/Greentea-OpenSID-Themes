<div class="py-5 text-center">
    <div class="container py-5">
      <div class="row" style="">
        <div class="mx-auto col-lg-8 col-md-10">
          <h1 contenteditable="true">Sinergi Program Desa <?php echo $desa['nama_desa'];?>&nbsp;</h1>
          <p class="mb-3 mx-auto w-75">Sinergi Program ditampilkan di sidebar modul Web, berisi tautan bergambar, yang akan membuka situs program-program pemerintah dan instansi lainnya yang penting bagi warga dan kepentingan desa.</p>
          <p class="mt-4 lead" style="">Sinergi Program&nbsp;<br></p>
          <div class="row text-muted">
          <?php foreach($sinergi_program as $key => $program) : ?>
            <div class="col-md-3 col-4 p-2"> 
            <a href="<?php echo $program['tautan']?>" title="<?php echo $program['judul']?>" target="_blank">
            <img class="img-fluid d-block" src="<?php echo base_url()?>desa/upload/widget/<?php echo $program['gambar']?>" alt="<?php echo $program['judul']?>"> 
            </div>
            </a>
            <?php endforeach; ?>        
        </div>
      </div>
    </div>
  </div>