<?php  if(!defined('BASEPATH')) exit('No direct script access allowed'); ?>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- PAGE settings -->
    <!--  favicon -->
		<?php if(is_file(LOKASI_LOGO_DESA.'/'.$desa['logo'])): ?>
			<link rel="shortcut icon" href="<?php echo base_url()?><?php echo LOKASI_LOGO_DESA.'/'.$desa[logo]; ?>" />
		<?php else: ?>
			<link rel="shortcut icon" href="<?php echo base_url()?>favicon.ico" />
		<?php endif; ?>

        <!-- Plugin Facebook Comment -->
        <div id="fb-root"></div>
        <script>(function(d, s, id) {
          var js, fjs = d.getElementsByTagName(s)[0];
          if (d.getElementById(id)) return;
          js = d.createElement(s); js.id = id;
          js.src = 'https://connect.facebook.net/id_ID/sdk.js#xfbml=1&version=v3.0&appId=378767258877343&autoLogAppEvents=1';
          fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));</script>
  <title>
        	<?php
			echo $this->setting->website_title
				. ' ' . ucwords($this->setting->sebutan_desa)
				. (($desa['nama_desa']).' '.ucwords($this->setting->sebutan_kecamatan." ".$desa['nama_kecamatan']).' '.ucwords($this->setting->sebutan_kabupaten." ".$desa['nama_kabupaten']) ? ' ' . $desa['nama_desa'].' '.ucwords($this->setting->sebutan_kecamatan." ".$desa['nama_kecamatan']).' '.ucwords($this->setting->sebutan_kabupaten." ".$desa['nama_kabupaten']) : '')
				. get_dynamic_title_page_from_path();
			?>
        </title>
  <meta name="description" content="Wireframe design of an album page by Pingendo">
  <meta name="keywords" content="Pingendo bootstrap example template wireframe album ">
  <meta name="author" content="Pingendo">
  