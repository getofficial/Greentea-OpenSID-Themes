
      
      
<?php if($single_artikel["id"]) : ?>  
  <div class="container" id="<?= 'artikel-'.$single_artikel['judul']?>">
  
    <div class="row">
      <!-- Post Content Column -->
      <div class="col-lg-8" style="	border-bottom-width: 10px;	border-style: solid;	border-top-width: 0px;	border-right-width: 0px;	border-left-width: 0px;	border-color: dark;">
      <!-- Title -->
        <h1 class="mt-4"><?php echo $single_artikel["judul"]?></h1>
        <!-- Author -->
        <p class="lead"> by <a href="#"><?= $single_artikel['owner']?></a>
        </p>
        <hr>
        <!-- Date/Time -->
        <p>Dipost <?= tgl_indo2($single_artikel['tgl_upload']);?></p>
        <hr>
        <!-- Preview Image -->
        <?php if($single_artikel['gambar']!='' and is_file(LOKASI_FOTO_ARTIKEL."sedang_".$single_artikel['gambar'])): ?><!-- Preview Image -->
		<a  href="<?= AmbilFotoArtikel($single_artikel['gambar'],'sedang')?>" title="">
		<img class="img-responsive" src="<?= AmbilFotoArtikel($single_artikel['gambar'],'sedang')?>" alt="" /> </a>
		<?php endif; ?>
        <hr>
        <!-- Post Content -->
        <p><?= $single_artikel["isi"]?></p>
        
         
         
        <!-- Comments Form -->
        <!-- Single Comment -->
        <!-- Comment with nested comments -->
        
      </div>
     
  
      <?php $this->load->view($folder_themes.'/partials/right.php');?>
    <?php endif; ?>
  </div>