<?php if ($agenda): ?>
 <!-- Sidebar Widgets Column -->
 <div class="col-md-4">
        <!-- Search Widget -->
        <br>
        <div class="card my-12">
          <h5 class="card-header bg-get">Search</h5>
          <div class="card-body">
            
            <form method="get" action="<?php echo site_url('first');?>" >
            <div class="input-group">
            <input type="text" name="cari" value="<?php echo $_GET['cari']; ?>" id="search">  </div> 
              <span class="input-group-btn">
                    <br>
                <button class="btn bg-get btn-primary" type="submit">Cari Artikel..</button>
              </span>
              </form>
            </div>
          </div>
       
        <!-- Categories Widget -->
        <div class="card my-4">
          <h5 class="card-header bg-get">Agenda</h5>
          <div class="card-body">
            <div class="row">
              <div class="col-lg-12">
                <ul class="list-unstyled mb-0">
                        <?php foreach ($agenda as $l): ?>
                <li><a href="<?= site_url("first/artikel/$l[id]")?>"><?= $l['judul']?> / <?= tgl_indo($l['tgl_upload'])?></a></li>
                <?php endforeach; ?>
                </ul>
              </div>
              <?php endif; ?>
          </div>
        </div>
    </div>
        <!-- Side Widget -->
        <div class="card my-4">
          <h5 class="card-header bg-get">Kategori</h5>
          
          <div class="card-body">
          
                                    <?php foreach($menu_kiri as $sub): ?>
                                    <li><a href="<?php echo site_url()."first/kategori/".$sub['id']?>"><?php echo $sub['nama']; ?></a></li>
                                    <?php endforeach; ?>
                              
                           
          </div>
        </div>
      </div>
    </div>
    <!-- /.row -->