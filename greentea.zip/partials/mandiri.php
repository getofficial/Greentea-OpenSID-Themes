<?php  if(!defined('BASEPATH')) exit('No direct script access allowed'); ?>
<div class="py-5 text-center" style="">
    <div class="container">
      <div class="row">
        <div class="mx-auto col-lg-5 col-md-7 col-10">
          <h1 style="" class="text-uppercase"><?php echo strtoupper(unpenetration($penduduk['nama']))?></h1>
          <h5 style="">NIK : <?php echo $penduduk['nik']?></h5>
        <a class="btn mx-3 btn-success " href="<?php echo site_url("first/cetak_biodata/$penduduk[id]"); ?>" style=""><i class="fa fa-fw fa-print"></i>&nbsp;PRINT</a>
        </div>
      </div>
    </div>
  </div>
  <div class="py-5">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <ul class="nav nav-tabs bg-get" >
            <li class="nav-item bg-get"> <a href="" class="active nav-link" data-toggle="pill" data-target="#tabone"><i class="fa fa-file fa-lg">&nbsp;Biodata</i></a> </li>
            <li class="nav-item"> <a class="nav-link" href="" data-toggle="pill" data-target="#tabtwo"><i class="fa fa-file fa-lg">&nbsp;Orang Tua</i></a> </li>
            <li class="nav-item " style=""> <a href="" class="nav-link" data-toggle="pill" data-target="#tabthree"><i class="fa fa-file fa-lg">&nbsp;Kelompok</i></a> </li>
          </ul>
          <div class="tab-content mt-2">
            <div class="tab-pane fade show active my-5" id="tabone" role="tabpanel">
              <div class="table-responsive">
                <table class="table table-bordered ">
                  <thead class="thead-dark">
                    <tr>
                      <th style="">KATEGORI DATA</th>
                      <th>DATA</th>
                    </tr>
                  </thead>
                  <tbody>
                  <tr>
                            <td width="36%">Nama</td>
                       
                            <td width="62%"><?php echo strtoupper(unpenetration($penduduk['nama']))?></td>
                            </tr>
                            <tr >
                            <td>NIK</td>
                            
                            <td><?php echo $penduduk['nik']?></td>
                            </tr>
                            <tr>
                            <td>No KK</td>
                            
                            <td><?php echo $penduduk['no_kk']?></td>
                            </tr>
                            <tr >
                            <td>Akta Kelahiran</td>
                            
                            <td><?php echo strtoupper($penduduk['akta_lahir'])?></td>
                            </tr>
                            <tr>
                            <td><?php echo ucwords($this->setting->sebutan_dusun)?></td>
                            
                            <td><?php echo strtoupper($penduduk['dusun'])?></td>
                            </tr>
                            <tr >
                            <td>RT/RW</td>
                            
                            <td><?php echo strtoupper($penduduk['rt'])?>/<?php echo $penduduk['rw']?></td>
                            </tr>
                            <tr>
                            <td>Jenis Kelamin</td>
                            
                            <td><?php echo strtoupper($penduduk['sex'])?></td>
                            </tr>
                            <tr >
                            <td>Tempat, Tanggal Lahir</td>
                            
                            <td><?php echo strtoupper($penduduk['tempatlahir'])?>, <?php echo strtoupper($penduduk['tanggallahir'])?></td>
                            </tr>
                            <tr>
                            <td>Agama</td>
                            
                            <td><?php echo strtoupper($penduduk['agama'])?></td>
                            </tr>
                            <tr >
                            <td>Pendidikan Dalam KK</td>
                            
                            <td><?php echo strtoupper($penduduk['pendidikan_kk'])?></td>
                            </tr>
                            <tr>
                            <td>Pendidikan yang sedang ditempuh</td>
                            
                            <td><?php echo strtoupper($penduduk['pendidikan_sedang'])?></td>
                            </tr>
                            <tr >
                            <td>Pekerjaan</td>
                            
                            <td><?php echo strtoupper($penduduk['pekerjaan'])?></td>
                            </tr>
                            <tr>
                            <td>Status Perkawinan</td>
                            
                            <td><?php echo strtoupper($penduduk['kawin'])?></td>
                            </tr>
                            <tr >
                            <td>Warga Negara</td>
                            
                            <td><?php echo strtoupper($penduduk['warganegara'])?></td>
                            </tr>
                            <tr>
                            <td>Dokumen Paspor</td>
                            
                            <td><?php echo strtoupper($penduduk['dokumen_pasport'])?></td>
                            </tr>
                            <tr >
                            <td>Dokumen Kitas</td>
                            
                            <td><?php echo strtoupper($penduduk['dokumen_kitas'])?></td>
                            </tr>
                            <tr>
                            <td>Alamat Sebelumnya</td>
                            
                            <td><?php echo strtoupper($penduduk['alamat_sebelumnya'])?></td>
                            </tr>
                            <tr >
                            <td>Alamat Sekarang</td>
                            
                            <td><?php echo strtoupper($penduduk['alamat'])?></td>
                            </tr>
                            <tr>
                            <td>Akta Perkawinan</td>
                            
                            <td><?php echo strtoupper($penduduk['akta_perkawinan'])?></td>
                            </tr>
                            <tr >
                            <td>Tanggal Perkawinan</td>
                            
                            <td><?php echo strtoupper($penduduk['tanggalperkawinan'])?></td>
                            </tr>
                            <tr>
                            <td>Akta Perceraian</td>
                            
                            <td><?php echo strtoupper($penduduk['akta_perceraian'])?></td>
                            </tr>
                            <tr >
                            <td>Tanggal Perceraian</td>
                            
                            <td><?php echo strtoupper($penduduk['tanggalperceraian'])?></td>
                            </tr>
                  </tbody>
                </table>
              </div>
            </div>
            <div class="tab-pane fade show active my-5" id="tabtwo" role="tabpanel">
              <div class="table-responsive">
                <table class="table table-bordered ">
                  <thead class="thead-dark">
                    <tr>
                      <th style="">KATEGORI DATA</th>
                      <th>DATA</th>
                    </tr>
                  </thead>
                  <tbody>
                  <tr>
                  <td width="36%">NIK Ayah</td>
      <td width="62%"><?php echo strtoupper($penduduk['ayah_nik'])?></td>
      
    </tr>
    <tr>
      
      <td>Nama Ayah</td>
     
      <td><?php echo strtoupper(unpenetration($penduduk['nama_ayah']))?></td>
      
    </tr>
    <tr>
      
    <td>NIK Ibu</td>
   
    <td><?php echo strtoupper($penduduk['ibu_nik'])?></td>
      
    </tr>
    <tr>
    <td>Nama Ibu</td>
   
    <td><?php echo strtoupper(unpenetration($penduduk['nama_ibu']))?></td>
      
    </tr>
    
    <tr>
    <td>Cacat</td>
                       
                        <td><?php echo strtoupper($penduduk['cacat'])?></td>
                        </tr>
                        <tr>
                        <td>Status</td>
                       
                        <td><?php echo strtoupper($penduduk['status'])?></td>
                        </tr>
   
                  </tbody>
                </table>
              </div>
            </div>
            <div class="tab-pane fade show active my-5" id="tabthree" role="tabpanel">
              <div class="table-responsive">
                <table class="table table-bordered ">
                  <thead class="thead-dark">
                    <tr>
                      <th >NAMA KELOMPOK</th>
                      <th>KATEGORI KELOMPOK</th>
                    </tr>
                  </thead>
                  <tbody>
                  <?php  foreach($list_kelompok as $kel){?>
        <tr>
        <td width="36%"><?php echo $kel['nama']?></td>
        
        <td width="62%"><?php echo $kel['kategori']?></td>

        </tr>
        <?php 
      }?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>