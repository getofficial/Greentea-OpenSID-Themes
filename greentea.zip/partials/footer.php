<?php  if(!defined('BASEPATH')) exit('No direct script access allowed'); ?>

    <div class="container-fluid py-5 text-white bg-get">
      <div class="row">
        <div class="col-md-6 text-center align-self-center p-4">
          <p class="mb-5"> <strong>Desa <?php echo $desa['nama_desa'];?>.</strong> <br><?php echo $desa['alamat_kantor']?><br> <abbr title="Phone">Tel : <?php echo $desa['telepon']?> </p>
          <div class="row">
          
          </div>
        </div>
        <div class="col-md-6 p-0 pr-5"> <iframe width="100%" height="350" src="https://maps.google.com/maps?q=marisa%20utara&t=&z=15&ie=UTF8&iwloc=&output=embed" scrolling="no" frameborder="0"></iframe></div>
      </div>
    </div>
  
  
  <div class="container-fluid  bg-dark">
      <div class="row">
        <div class="col-md-12 mt-3 text-center">
          <p class="text-light">© Copyright 2019 Getoficial - OpenSID | Themes Greentea .</p>
        </div>
      </div>
    </div>
  
  
  
  