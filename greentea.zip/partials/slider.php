<?php  if(!defined('BASEPATH')) exit('No direct script access allowed'); ?>
<div class="text-center py-5 bg-get">
    <div class="container">
      <div class="row my-5 justify-content-center">
        <div class="col-md-6">
        <div class="card card-shadow">
           
            <div class="card-body">
              <blockquote class="blockquote mb-0 text-left">
                <h5 >Melalui website ini kami berupaya menghadirkan informasi seputar kegiatan dan program pemerintah 	<?php
			echo $this->setting->website_title
				. ' ' . ucwords($this->setting->sebutan_desa)
				. (($desa['nama_desa']).' '.ucwords($this->setting->sebutan_kecamatan." ".$desa['nama_kecamatan']).' '.ucwords($this->setting->sebutan_kabupaten." ".$desa['nama_kabupaten']) ? ' ' . $desa['nama_desa'].' '.ucwords($this->setting->sebutan_kecamatan." ".$desa['nama_kecamatan']).' '.ucwords($this->setting->sebutan_kabupaten." ".$desa['nama_kabupaten']) : '')
				. get_dynamic_title_page_from_path();
			?>, Website ini kami hadirkan untuk mengikuti perkembangan dunia Teknologi Informasi (IT) yang kian pesat. Lahir dari sebuah ide kreatif dan inovatif, serta merupakan sebuah terobosan kami untuk lebih mendekatkan diri kepada masyarakat luas. Kami berupaya agar informasi menjadi lebih terbuka dan interaktif.</h5>
                <footer class="blockquote-footer">Kepala Desa <?php echo $desa['nama_desa'];?></footer>
              </blockquote>
            </div>
          </div>
        </div>
        <div class="col-md-6">
        <img src="https://i.ibb.co/3TzYDQr/sedang-e9jv-Yg-Whats-App-Image-2018-11-28-at-11-33-11-PM-Recovered.jpg" width="500" height="332" alt="" srcset="">
        </div>
      </div>
    </div>
  </div>