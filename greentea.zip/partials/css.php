<?php  if(!defined('BASEPATH')) exit('No direct script access allowed'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" type="text/css">
  <link rel="stylesheet" href='<?php echo base_url("$this->theme_folder/themes1/cssku/cssku.css"); ?>' type="text/css"> 
  <link type="text/css" rel="stylesheet" charset="UTF-8" href="https://translate.googleapis.com/translate_static/css/translateelement.css">
  <link rel="stylesheet" href='<?php echo base_url("$this->theme_folder/themes1/swipper/css/swiper.min.css"); ?>' type="text/css"> 
 
